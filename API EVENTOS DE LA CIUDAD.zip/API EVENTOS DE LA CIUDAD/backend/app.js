const dbTool = require('./db.js');

function CrearEvento(Estado, Ciudad, Nombre, TipoEvento , Descripcion, fecha, Presupuesto, LinkUbicacion, ForoMax, ForoActual) {
    let data = dbTool.cargarDatos();

    let idNueva = Object.keys(data).length ? Math.max(Object.keys(data).map(Number)) + 1 : 1;

    data[idNueva] = {
        estado: Estado,
        ciudad: Ciudad,
        evento: Nombre,
        tipos_evento: TipoEvento,
        descripcion: Descripcion,
        fecha: fecha,
        presupuesto: Presupuesto,
        ubicacion: LinkUbicacion ,
        foro: ForoMax,
        foro_actual: ForoActual
       };

       dbTool.guardarDatos(data);
}

//CrearEvento("Chihuahua", "Chihuahua", "TUboda", "Expoboda", "Ven y programa sin omar", "22/03/2023", 1000, "https://www.google.com", 100, 0);

function leerPartidas() {
    return dbTool.cargarDatos();
}

function leerEvento(id) {
    let data = dbTool.cargarDatos();
    return data[id] || "La partida no existe.";
}

function actualizarEvento(id, Estado, Ciudad, Nombre, TipoEvento , Descripcion, fecha, Presupuesto, LinkUbicacion, ForoMax, ForoActual) {
    let data = dbTool.cargarDatos();

    if (!data[id]) {
        console.log(`Partida con ID ${id} no existe.`);
        return;
    }

    nuevosDatos = [Estado, Ciudad, Nombre, TipoEvento , Descripcion, fecha, Presupuesto, LinkUbicacion, ForoMax, ForoActual]; 
    
    Object.assign(data[id], nuevosDatos);
    dbTool.guardarDatos(data);
    console.log("Partida actualizada correctamente.");
}

function eliminarPartida(id) {
    let data = dbTool.cargarDatos();
    if (data[id]) {
        delete data[id];
        dbTool.guardarDatos(data);
        console.log("Partida eliminada.");
    } else {
        console.log("ID no existe.");
    }
}






//CrearEvento("AYUDA");
//eliminarPartida("1");
console.log(leerEvento("3"));
