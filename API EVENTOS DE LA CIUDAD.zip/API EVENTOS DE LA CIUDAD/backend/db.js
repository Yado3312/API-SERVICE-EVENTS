const fs = require('fs');
const FILE_NAME = "eventosDB.json";

function cargarDatos() {
    try {
        const data = fs.readFileSync(FILE_NAME, 'utf8');
        return JSON.parse(data);
    } catch (err) {
        return {};  
    }
}

function guardarDatos(data) {
    fs.writeFileSync(FILE_NAME, JSON.stringify(data, null, 4));
}

module.exports={
    cargarDatos,
    guardarDatos
}