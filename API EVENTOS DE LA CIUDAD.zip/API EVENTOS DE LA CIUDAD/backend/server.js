const express = require('express');
const cors = require('cors'); 
const path = require('path');
const dbTool = require('./db.js');

const app = express();
const port = 3000;

app.use(cors()); 
app.use(express.json());


app.use(express.static(path.join(__dirname, '../frontend')));


app.get("/", (req, res) => {
    res.sendFile(path.join(__dirname, "../frontend/index.html"));
});


app.get('/eventos', (req, res) => {
    try {
        const eventos = dbTool.cargarDatos();
        const eventosArray = Object.keys(eventos).map(key => eventos[key]);
        res.json(eventosArray);
    } catch (error) {
        res.status(500).json({ mensaje: "Errol cargar los events", error: error.message });
    }
});


app.listen(port, () => {
    console.log(`Servidor corriendoOOO en http://localhost:${port}`);
});
