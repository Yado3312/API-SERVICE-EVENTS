function filtrarEventos(eventos, presupuesto, tipoEvento) {
    return eventos.filter(evento => {
        // Filtro del presupuesto 
        const cumplePresupuesto = (presupuesto === "todos") || 
            (presupuesto === "bajo" && evento.presupuesto < 500) ||
            (presupuesto === "medio" && evento.presupuesto >= 500 && evento.presupuesto <= 1000) ||
            (presupuesto === "alto" && evento.presupuesto > 1000);

        // Filtro de evento
        const cumpleTipo = (tipoEvento === "todos") || 
            (evento.tipos_evento === tipoEvento); 

        return cumplePresupuesto && cumpleTipo;
    });
}

// Aproximacion en de 7 dias
function filtrarEventosProximaSemana(eventos) {
    const hoy = new Date();
    const enUnaSemana = new Date();
    enUnaSemana.setDate(hoy.getDate() + 7);

    return eventos.filter(evento => {
        const fechaEvento = new Date(evento.fecha);
        return fechaEvento >= hoy && fechaEvento <= enUnaSemana;
    });
}

function crearElementosCarrusel(eventos) {
    const carruselInner = document.getElementById("Carrusel");
    carruselInner.innerHTML = "";

    // solo si no hay eventos 
    if (eventos.length === 0) {
        carruselInner.innerHTML = `
            <div class="carousel-item active">
                <img src="https://via.placeholder.com/800x400?text=No+hay+eventos+esta+semana" class="d-block w-100" alt="No hay eventos">
                <div class="carousel-caption d-none d-md-block">
                    <h5>No hay eventos esta semana</h5>
                    <p>Vuelve a revisar mqzs tarde.</p>
                </div>
            </div>
        `;
    } else {
        eventos.forEach((evento, index) => {
            const carruselItem = document.createElement("div");
            carruselItem.classList.add("carousel-item");
            if (index === 0) carruselItem.classList.add("active");

            const imagenFondo = evento.imagen || "https://via.placeholder.com/800x400";
            carruselItem.setAttribute("data-id", evento.id); 
            carruselItem.innerHTML = `
                <img src="${imagenFondo}" class="d-block w-100" alt="${evento.evento}">
                <div class="carousel-caption d-none d-md-block">
                    <h5>${evento.evento}</h5>
                    <p>${evento.descripcion || "Descripcion no disponible"}</p>
                </div>
            `;

            carruselInner.appendChild(carruselItem);
        });

       // Boton para las espesificaicones del carrusel
        const botonEspecificaciones = document.getElementById("botonEspecificaciones");
        botonEspecificaciones.addEventListener("click", () => {
            const eventoActivo = eventos.find((evento, index) => {
                const carruselItem = document.querySelector(`.carousel-item:nth-child(${index + 1})`);
                return carruselItem.classList.contains("active");
            });

            if (eventoActivo) {
                mostrarDetalles(eventoActivo.id); // Mostrar los detalles del evento activo en el modal
            } else {
                // Si no se encuentra el evento activo, mostrar un mensaje de error
                document.getElementById("modalEventoBody").innerHTML = `
                    <div class="alert alert-danger" role="alert">
                        No se encontrg el evento activo.
                    </div>
                `;
            }
        });
    }
}

// Creamos las cartas con sus estructura html dentro 
function crearCarta(evento) {
    const carta = document.createElement("div");
    carta.classList.add("col-md-12", "card-container");

    const imagenFondo = evento.imagen || "ruta/a/imagen/default.jpg"; // Imagen por defecto si no hay una
    carta.innerHTML = `
        <div class="card" style="background-image: url('${imagenFondo}'); background-size: cover; background-position: center;">
            <div class="card-footer" style="background: black;">
                <p style="color: white; text-align: center; padding: 10px;">${evento.evento}</p>
                <button class="btn btn-primary mt-2" data-bs-toggle="modal" data-bs-target="#modalEvento" data-id="${evento.id}">
                    <i class="fa-solid fa-eye"></i>
                </button>
            </div>
        </div>
    `;
    return carta;
}

function mostrarDetalles(eventoId) {
    const eventos = JSON.parse(localStorage.getItem("eventos")) || [];
    const evento = eventos.find(e => e.id === eventoId); 

    if (evento) {
        // Mostrar info modal
        document.getElementById("modalEventoImagen").src = evento.imagen || "https://via.placeholder.com/800x400";
        document.getElementById("modalEventoTitulo").innerText = evento.evento;
        document.getElementById("modalEventoDescripcion").innerText = evento.descripcion || "No disponible";
        document.getElementById("modalEventoFecha").innerText = evento.fecha;
        document.getElementById("modalEventoHora").innerText = evento.hora || "No especificada";
        document.getElementById("modalEventoPresupuesto").innerText = `$${evento.presupuesto || "No especificado"}`;
        document.getElementById("modalEventoForo").innerText = `${evento.foro} personas (${evento.foro_actual} registradas)`;
        document.getElementById("modalEventoUbicacion").innerHTML = evento.ubicacion || "Ubicación no disponible.";
    } else {
        // Solo si no hay eventos
        document.getElementById("modalEventoBody").innerHTML = `
            <div class="alert alert-danger" role="alert">
                No se encontro la informacion del evento.
            </div>
        `;
    }
}

// imprimimos las cartas pero limpiamos
function imprimirCartas(eventos) {
    const contenedor = document.getElementById("card-container");
    contenedor.innerHTML = ""; 

    eventos.forEach(evento => {
        const carta = crearCarta(evento);
        contenedor.appendChild(carta);
    });

    configurarBotonesDetalles(); // configuramos los botones
}

// Actuializamos cada carta 
function actualizarCartas() {
    const eventos = JSON.parse(localStorage.getItem("eventos")) || [];
    const presupuesto = document.getElementById("filtroPresupuesto").value;
    const tipoEvento = document.getElementById("filtroTipoEvento").value;

    const eventosFiltrados = filtrarEventos(eventos, presupuesto, tipoEvento);

    imprimirCartas(eventosFiltrados);
}

// Configurar el carrusel para activar la animación cuando cambie de item
const carrusel = document.getElementById("carouselExampleIndicators");
carrusel.addEventListener("slid.bs.carousel", () => {
    activarAnimacionBoton();
});


document.getElementById("filtroPresupuesto").addEventListener("change", actualizarCartas); // actualizamos las cartas cuando cambie el presupuesto
document.getElementById("filtroTipoEvento").addEventListener("change", actualizarCartas); // actualizamos las cartas cuando cambie el tipo de evento


function configurarBotonesDetalles() {
    const botonesVerDetalles = document.querySelectorAll(".btn[data-bs-toggle='modal']");

    botonesVerDetalles.forEach(boton => {
        boton.addEventListener("click", () => {
            const eventoId = boton.getAttribute("data-id"); // Obtener el ID del evento
            mostrarDetalles(eventoId); // Mostrar los detalles del evento en el modal
        });
    });
}

window.onload = () => {
    fetch('/eventos')
        .then(response => response.json())
        .then(eventos => {
            // TODOS LOS EVENTOS TIENEN QUE TENER ID
            eventos.forEach((evento, index) => {
                evento.id = evento.id || `evento-${index}`; // GENERAMOS UNA ID PARA QUE NO SE PIERDA EL INDICE
            });

            localStorage.setItem("eventos", JSON.stringify(eventos));

            // Se muestran al inicio los evtos
            actualizarCartas();

            // Priorizamos los siguientes 7 dias de eventos
            const eventosProximaSemana = filtrarEventosProximaSemana(eventos);
            crearElementosCarrusel(eventosProximaSemana);
        })
        .catch(error => console.error('Error al cargar los eventos:', error));
};